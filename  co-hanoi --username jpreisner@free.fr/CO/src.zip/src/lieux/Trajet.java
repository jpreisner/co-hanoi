package lieux;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;

public class Trajet {
    private String nom;
    private Lieu depart;
    private Lieu arrivee;
    private Heure dateDepart;
    private ArrayList<Etape> sesEtapes;

    public Trajet(String n, Lieu dep, Lieu arr, Heure d,
		  ArrayList<Etape> etapes) {
	nom = n;
	depart = dep;
	arrivee = arr;
	dateDepart = d;
	sesEtapes = etapes;
    }

    public String nom() { return nom; }

    public Lieu depart() { return depart; }

    public Lieu arrivee() { return arrivee; }

    public void liste() {
	System.out.println("Trajet " + nom + " de " + depart.nom() + " a " 
			   + arrivee.nom() + ", depart a " + dateDepart + " :");
	for(Etape e: sesEtapes) e.liste();
    }

    public boolean estCoherent() {
    	// On test si d�part = arriv�e
    	if(depart.equals(arrivee) || arrivee.equals(depart)){
    		return false;
    	}
    	int i;
    	for (i=0; i<sesEtapes.size(); i++){
    		// On regarde si arrivee(i) = depart (i+1)
    		if(!(sesEtapes.get(i).arrivee().equals(sesEtapes.get(i+1).depart()))){
    			return false;
    		}
    		if(sesEtapes.get(i).depart().equals(sesEtapes.get(i).arrivee())){
    			return false;
    		}
    		if(sesEtapes.get(i).hDepart().compareTo(sesEtapes.get(i).hArrivee()) > 0){
    			return false;
    		}
    		
    	}
    	
	return true;
    }

    public Heure hArrivee() throws ErreurTrajet, ErreurHeure {
    	Heure hArr = new Heure();
    	hArr.add(dateDepart);
    	for (Etape etape : sesEtapes){
    		// additionner tous les temps de chaque etape
    	}
    	return hArr;
    }

    public Heure duree() throws ErreurTrajet {
	return null;
    }

    public Heure attente() throws ErreurTrajet {
	return null;
    }

    public int nbChgt() throws ErreurTrajet {
	return 0;
    }


    public static Trajet meilleur(Collection<Trajet> col, Comparateur comp)
    throws ErreurTrajet {
	return null;
    }

}
