package lieux;
import java.util.Comparator;

// Juste pour donner un nom a l'interface.
interface Comparateur extends Comparator<Trajet> {
}
