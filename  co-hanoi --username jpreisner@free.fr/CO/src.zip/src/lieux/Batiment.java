package lieux;

public class Batiment extends Lieu {
	
    public Batiment(String nom) {
	super(nom);
    }
}
