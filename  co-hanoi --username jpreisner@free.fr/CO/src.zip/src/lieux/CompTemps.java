package lieux;

public class CompTemps implements Comparateur {

	@Override
	public int compare(Trajet arg0, Trajet arg1) {
		// TODO Auto-generated method stub
		return 0;
	}

}