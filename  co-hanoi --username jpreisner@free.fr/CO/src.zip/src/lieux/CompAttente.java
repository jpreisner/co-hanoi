package lieux;

public class CompAttente implements Comparateur {

}