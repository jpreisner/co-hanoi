package hanoi1;

public class ErreurPile extends Exception {

    public ErreurPile() {
    	super();
    }

    public ErreurPile(String msg) {
    	super(msg);
    }
}
